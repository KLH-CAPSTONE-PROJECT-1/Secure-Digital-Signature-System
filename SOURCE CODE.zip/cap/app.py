from flask import Flask, render_template, request, flash
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding, rsa
import os

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Replace with a strong, random secret key

# Define private_key at the module level
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

@app.route('/index')
def index_page():
    return render_template('index.html')

@app.route('/sign')
def sign_page():
    return render_template('sign.html')

@app.route('/verify')
def verify_page():
    return render_template('verify.html')


@app.route('/index, method[POST]')
def index():
    if 'document' in request.files:
        
        return render_template('index.html')


@app.route('/sign', methods=['POST'])
def sign_document():
    if 'document' in request.files:
        document = request.files['document'].read()

        # Calculate the hash of the document
        digest = hashes.Hash(hashes.SHA256())
        digest.update(document)
        hash_value = digest.finalize()

        # Sign the hash with the private key
        signature = private_key.sign(
            hash_value,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )

        # Save the signature to a file or database
        with open('signature.sig', 'wb') as sig_file:
            sig_file.write(signature)

        flash('Document signed successfully.', 'success')
    else:
        flash('No document selected for signing.', 'danger')

    return render_template('sign.html')

@app.route('/verify', methods=['POST'])
def verify_signature():
    if 'document' in request.files:
        document = request.files['document'].read()

        # Load the signature from a file or database
        if os.path.exists('signature.sig'):
            with open('signature.sig', 'rb') as sig_file:
                signature = sig_file.read()

            public_key = private_key.public_key()
            digest = hashes.Hash(hashes.SHA256())
            digest.update(document)
            hash_value = digest.finalize()

            try:
                public_key.verify(
                    signature,
                    hash_value,
                    padding.PSS(
                        mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH
                    ),
                    hashes.SHA256()
                )
                flash('Signature is valid. Document is authentic.', 'success')
            except Exception as e:
                flash('Signature verification failed. Document may be tampered with.', 'danger')
        else:
            flash('Signature not found. Cannot verify.', 'danger')

    return render_template('verify.html')

if __name__ == '__main__':
    app.run(debug=True)
